# Data Dictionary — Aviation Customer Analytics Dataset

## customer_master.csv
| Column | Type | Description | Valid Range / Values |
|---|---|---|---|
| customer_id | string | Unique passenger identifier (PK) | CUST000001 … |
| first_name | string | Passenger first name | Non-null |
| last_name | string | Passenger last name | Non-null |
| email | string | Contact email | Valid email format |
| age | integer | Age in years | 18–75 |
| gender | string | Gender identity | M / F / Other |
| home_city | string | City of residence | Non-null |
| home_country | string | Country of residence | Non-null |
| home_airport | string | Nearest hub airport (IATA) | 3-letter IATA code |
| loyalty_tier | string | Frequent-flyer tier | Bronze / Silver / Gold / Platinum |
| loyalty_points | integer | Accrued points balance | ≥ 0 |
| enrolment_date | date | Date joined loyalty programme | YYYY-MM-DD |
| preferred_cabin | string | Self-declared cabin preference | Economy / Premium Economy / Business / First |

## flight_transactions.csv
| Column | Type | Description | Valid Range / Values |
|---|---|---|---|
| booking_id | string | Unique booking identifier (PK) | BK00000001 … |
| customer_id | string | FK → customer_master | Must exist in customer_master |
| booking_date | date | Date booking was made | YYYY-MM-DD |
| flight_date | date | Actual travel date | YYYY-MM-DD, ≥ booking_date |
| origin_airport | string | Departure IATA code | 3-letter code |
| destination_airport | string | Arrival IATA code | 3-letter code, ≠ origin |
| airline | string | Operating carrier | Non-null |
| cabin_class | string | Cabin purchased | Economy / Premium Economy / Business / First |
| base_fare_inr | float | Ticket fare in INR | > 0 |
| ancillary_spend_inr | float | Ancillary add-ons (INR) | ≥ 0 |
| total_spend_inr | float | base_fare + ancillary | > 0 |
| miles_earned | integer | Loyalty miles credited | ≥ 0 |
| travel_purpose | string | Self-declared trip purpose | Leisure / Business / Family Visit / Medical / Education |
| booking_lead_days | integer | Days between booking & travel | 0–180 |
| flight_on_time | integer | 1 = on-time, 0 = delayed | 0 or 1 |

## customer_feedback.csv
| Column | Type | Description | Valid Range / Values |
|---|---|---|---|
| feedback_id | string | Unique survey response ID (PK) | FB00000000 … |
| booking_id | string | FK → flight_transactions | Must exist in transactions |
| customer_id | string | FK → customer_master | Must exist in customer_master |
| feedback_date | date | Date feedback was submitted | YYYY-MM-DD |
| overall_satisfaction | float | Overall flight rating | 1.0–5.0 |
| seat_comfort | float | Seat comfort score | 1.0–5.0 |
| cabin_crew_service | float | Crew rating | 1.0–5.0 |
| food_quality | float | Food & beverage rating | 1.0–5.0 |
| in_flight_entertainment | float | IFE rating | 1.0–5.0 |
| punctuality_score | float | On-time performance rating | 1.0–5.0 |
| nps_score | integer | Net Promoter Score (0–10) | 0–10 |
| would_recommend | integer | 1 = would recommend airline | 0 or 1 |

## Sources
Dataset is synthetically generated using `scripts/generate_synthetic_data.py` (seed=42).
All customer names, emails, and identifiers are fictitious.
Fare figures are approximate INR values for India-originated routes (2022-2024 range).
